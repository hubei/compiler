void arr[10];
