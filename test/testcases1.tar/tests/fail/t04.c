void print (int i);
int print (int i);
