int print ();

int print () {
  return 0;
}
